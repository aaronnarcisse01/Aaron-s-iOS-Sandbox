import UIKit

var greeting = "Hello, playground"
let pi: Double = .pi
let piString = String(format: "%.6f", pi)
print(piString)

// MARK: Test Time Strings
let timeString1 = "12:03:34PM"
let timeString2 = "1:04:34PM"
let timeString3 = "12:32:32AM"
let timeString4 = "03:31:56PM"
let timeString5 = "03:31:56AM"
func testWithTimeStrings(_ f: (String) -> String) {
    f(timeString1)
    f(timeString2)
    f(timeString3)
    f(timeString4)
    f(timeString5)
    print()
}

// MARK: Method 1
func convertToMilitaryMethod1(_ timeString: String) -> String {
    // convert to array of Strings, removing ":"
    var timeStringSeparated = timeString.split(separator: ":").map {String($0)}
    // separate seconds from AM/PM designation
    let str = timeStringSeparated[2]
    timeStringSeparated[2] = String(str.dropLast(2))
    let twelveHourTag = String(str.dropFirst(2))
    // add 12 to 1PM...11PM and make 12AM == 00
    if let hour = Int(timeStringSeparated[0]) {
        var h = hour
        if h < 12 && twelveHourTag == "PM" {
            h += 12
        } else if h == 12 && twelveHourTag == "AM" {
            h = 0
        }
        timeStringSeparated[0] = String(format: "%02d", h)
    }
    // reassemble string
    let result = timeStringSeparated.joined(separator: ":")
    print(result)
    return result
}

testWithTimeStrings(convertToMilitaryMethod1)

// MARK: Method 2
func convertToMilitaryMethod2(_ timeString: String) -> String {
    var arr: [String] = []
    for c in timeString {
        arr.append(String(c))
    }
    if arr[1] == ":" {
        arr.insert("0", at: 0)
    }
    func stringFrom(indices: Int...) -> String {
        var s = ""
        for i in indices {
            s.append(arr[i])
        }
        return s
    }
    var hourString = stringFrom(indices: 0,1)
    let minuteString = stringFrom(indices: 3,4)
    let secondString = stringFrom(indices: 6,7)
    let twelveHourSpecifier = stringFrom(indices: 8,9)
    if let h = Int(hourString) {
        if twelveHourSpecifier == "AM" {
            if h == 12 {
                hourString = "00"
            }
        } else {
            if h < 12 {
                hourString = String(format: "%02d", h + 12)
            }
        }
    }
    let result = hourString + ":" + minuteString + ":" + secondString
    print(result)
    return result
}

testWithTimeStrings(convertToMilitaryMethod2)

var string = "abcdefg"
let stringArrary: [String] = {
    var result: [String] = []
    for c in string {
        result.append(String(c))
    }
    return result
}()
print(stringArrary)
let index = string.firstIndex(of: "e")
let offset = string.insert(Character("x"), at: index!)
print(string)


// MARK: Caesar Cypher:

func caesarCipher(s: String, k: Int) -> String {
    // Write your code here
    var arr: [String] = []
    for c in s {
        arr.append(String(c))
    }
    let lowercase = "abcdefghijklmnopqrstuvwxyz"
    let uppercase = lowercase.uppercased()
    func getReplacement(for s: String, from str: String) -> String {
        var arr: [String] = []
        var k = k
        var i = 0
        var shouldIncrement = true
        for c in str {
            let e = String(c)
            arr.append(e)
            if e == s {
                shouldIncrement = false
            } else if shouldIncrement {
                i += 1
            }
        }
        k += i
        k %= 26
        return arr[k]
    }
    func getReplacement(for s: String) -> String {
        if lowercase.contains(s) {
            return getReplacement(for: s, from: lowercase)
        } else if uppercase.contains(s) {
            return getReplacement(for: s, from: uppercase)
        } else {
            return s
        }
    }
    var result = ""
    for s in arr {
        let newLetter = getReplacement(for: s)
        result += newLetter
    }
    return result
}
caesarCipher(s: "Always-Look-on-the-Bright-Side-of-Life", k: 5)

// MARK: Palindrome Index
// returns index of letter that can make a string a palindrome if removed (may have multiple answers, any will do)
// if there isn't one, or the string is already a palindrome, return -1
func palindromeIndex(s: String) -> Int {
    print(#function)
    // Write your code here
    var stringArr: [String] = []
    for c in s {
        stringArr.append(String(c))
    }
    print(stringArr)
    func isPalindrome(_ arr: [String]) -> Bool {
        print(#function)
        var i = 0
        var j = arr.count - 1
        while i < j {
            print(i)
            print(j)
            let e1 = arr[i]
            let e2 = arr[j]
            if e1 != e2 {
                //print("It is not a palindrome")
                return false
            } else {
                i += 1
                j -= 1
            }
        }
        print("It is a palindrome")
        return true
    }
    func makePalindrome(_ arr: [String]) -> Int? {
        var i = 0
        var j = arr.count - 1
        while i < j {
            let e1 = arr[i]
            let e2 = arr[j]
            
            if e1 != e2 {
                var version1 = arr
                let _ = version1.remove(at: i)
                print(version1)
                var version2 = arr
                let _ = version2.remove(at: j)
                print(version2)
                if isPalindrome(version1) {
                    return i
                } else if isPalindrome(version2) {
                    return j
                }
            }
            i += 1
            j -= 1
        }
        return nil
    }
    if let i = makePalindrome(stringArr) {
        return i
    } else {
        return -1
    }
}
palindromeIndex(s: "asdfjkl;;lkjfdsa")
palindromeIndex(s: "asdffdsxa")
